const mongoose= require('mongoose');
const Park= require("../Models/park.model");

const connectToMongoDB= () => {
    const mongodbUri= process.env.MONGODB_URI;
  mongoose.connect(mongodbUri);
  

  mongoose.connection.on('connected', () => {
    console.log('Connected to MongoDB');
    Park.compileParkModel();
  });

  mongoose.connection.on('error', (error) => {
    console.error('Failed to connect to MongoDB', error);
  });
}

const disconnectFromMongoDB= () => {
  mongoose.disconnect(() => {
    console.log('Disconnected from MongoDB');
  });
}

module.exports= {
  connect: connectToMongoDB,
  disconnect: disconnectFromMongoDB
}
