const Park= require("../Models/park.model");

const callbackify= require("util").callbackify;


const createPark= callbackify(function(requestBody){
   const { parkName, state, size, parkDetails }= requestBody;

    const ParkModelConstructor= Park.getParkModel();

    const parkModelInstance= new ParkModelConstructor({
    parkName,
    state,
    size,
    parkDetails
    });

    return parkModelInstance.save();

  });


  const getAllParks= callbackify(function() {
    return Park.getParkModel().find();
  });
  
  const getParkById= callbackify(function(parkId) {
    return Park.getParkModel().findById(parkId);
  });
  
  const partialUpdatePark= callbackify(function(parkId, updatedPark) {
    return _updatePark(parkId, updatedPark);
  });

  const fullUpdatePark= callbackify(function(parkId, updatedPark) {
    return _updatePark(parkId, updatedPark);
  });

  function _updatePark(parkId, updatedPark){
   return  Park.getParkModel().findByIdAndUpdate(parkId, updatedPark, { new: true });
  }
  
  const deletePark= callbackify(function(parkId) {
    return Park.getParkModel().findByIdAndRemove(parkId);
  });


module.exports= {
    createPark:  createPark,
    getAllParks: getAllParks,
    getParkById: getParkById,
    partialUpdatePark:  partialUpdatePark,
    fullUpdatePark: fullUpdatePark,
    deletePark:  deletePark
}