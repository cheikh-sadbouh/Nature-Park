const parkService = require("./park.service");

const callbackify= require("util").callbackify;


const addAndUpdateParkDetails= callbackify(function(park ,requestBody){
   const { picture,description,category }= requestBody;
    console.log(park);

    park.parkDetails= {
        picture: picture,
        description: description,
        category:  category
    }
      return  park.save();
 
});

const removeParkDetails= callbackify(function(park){
       park.parkDetails= null;
       return  park.save();
  
 });




module.exports= {
    addParkDetails:  addAndUpdateParkDetails,
    fullUpdateParkDetails: addAndUpdateParkDetails,
    partialUpdateParkDetails: addAndUpdateParkDetails,
    getParkById: parkService.getParkById,
    removeParkDetails: removeParkDetails
}