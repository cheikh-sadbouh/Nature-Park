require('dotenv').config();
require('./Configs/mongodbConnectionAdapter').connect();


const express= require('express');
const bodyParser= require('body-parser');
const parkRoutes= require("./Routes/park.route");

const app= express();
app.use(bodyParser.json());
app.use(parkRoutes);



app.listen(process.env.PORT, () => {
  console.log(`Server started on port ${process.env.PORT}`);
});

