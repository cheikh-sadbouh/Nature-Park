const mongoose= require('mongoose');

const parkDetailsSchema= new mongoose.Schema({
  picture:  {
    type: String,
    required:true
},
  description:  {
    type: String,
    required:true
},
  category:  {
    type: String,
    required:true
}    
});

const parkSchema= new mongoose.Schema({
    parkName: {
        type: String,
        required:true
    },
    state:  {
        type: String,
        required:true
    },
    parkDetails: {
      type: parkDetailsSchema,
      require: true
    }
    });
  
  let _park= null;

  const  compileParkModel = function(){
    if(_park == null) {
         _park= mongoose.model(process.env.PARK_DOCUMENT, parkSchema, process.env.NATUREPARK_COLLECTION);
       return _park;
    }

  }
  const getParkModel= function(){
    return _park;
  }
   module.exports= {
    getParkModel: getParkModel,
    compileParkModel: compileParkModel
  };