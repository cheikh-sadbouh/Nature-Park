

  const validateRequestBodyForParkDetails= (req, res, next) => {
    console.log("Middleware executed for ",req.url);
    const { picture,description,category }= req.body;
  
    if ( !picture || !description || !category) {
      res.status(process.env.CLIENT_ERROR).json({ error: "Request body is missing required 'parkDetails' properties" });
    } else {
      next();
    }
  };

  const validateRequestBodyForPark= (req, res, next) => {
    console.log("Middleware executed for ",req.url);
    const { parkDetails,parkName,state}= req.body;
  
    if ( !parkDetails.picture || !parkDetails.description || !parkDetails.category || !parkName || !state) {
      res.status(process.env.CLIENT_ERROR).json({ error: "Request body is missing required 'park' properties" });
    } else {
      next();
    }
  };
  
  module.exports= {
    validateRequestBodyForParkDetails:validateRequestBodyForParkDetails,
    validateRequestBodyForPark: validateRequestBodyForPark
  }