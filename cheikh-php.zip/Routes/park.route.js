const parkController= require("../Controllers/park.controller");
const parkDetailsController= require("../Controllers/parkDetails.controller");

const filter = require("../Middleware/parkDetails.middleware");

const express= require("express");

const router= express.Router();

router.route("/parks")
   .post(filter.validateRequestBodyForPark,parkController.addPark)
   .get(parkController.getParks);

router.route("/parks/:id")
        .get(parkController.getParkById)
        .put(filter.validateRequestBodyForPark,parkController.fullUpdatePark)
        .patch(parkController.partialUpdatePark)
        .delete(parkController.deletePark);

router.route("/parks/:id/park-details")
      .post(filter.validateRequestBodyForParkDetails,parkDetailsController.addParkDetails)
      .get(parkDetailsController.findParkDetails)
      .put(filter.validateRequestBodyForParkDetails,parkDetailsController.fullUpdateParkDetails)
      .patch(parkDetailsController.partialUpdateParkDetails)
      .delete(parkDetailsController.removeParkDetails);

   

module.exports= router;
