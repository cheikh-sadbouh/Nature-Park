const parkDetailsService = require("../Services/parkDetails.service");

const _getParkDetailsAndPerformAction = (parkId, actionCallback, res) => {
  parkDetailsService.getParkById(parkId, (error, park) => {
    if (error) {
      res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to retrieve park" + error });
    } else if (!park) {
      res.status(process.env.NOT_FOUND).json({ error: "Park not found" });
    } else {
      actionCallback(park, res);
    }
  });
};

const addParkDetails = (req, res) => {
  const parkId = req.params.id;
  const parkDetails = req.body;

  _getParkDetailsAndPerformAction(parkId, (park, res) => {
    parkDetailsService.addParkDetails(park, parkDetails, (error, park) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to add park details" + error });
      } else {
        res.status(process.env.OK).json(park.parkDetails);
      }
    });
  }, res);
};

const partialUpdateParkDetails = (req, res) => {
  const parkId = req.params.id;
  const parkDetails = req.body;

  _getParkDetailsAndPerformAction(parkId, (park, res) => {
    parkDetailsService.partialUpdateParkDetails(park, parkDetails, (error, park) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to update park details" + error });
      } else {
        res.status(process.env.OK).json(park.parkDetails);
      }
    });
  }, res);
};

const fullUpdateParkDetails = (req, res) => {
  const parkId = req.params.id;
  const parkDetails = req.body;

  _getParkDetailsAndPerformAction(parkId, (park, res) => {
    parkDetailsService.fullUpdateParkDetails(park, parkDetails, (error, park) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to update park details" + error });
      } else {
        res.status(process.env.OK).json(park.parkDetails);
      }
    });
  }, res);
};

const findParkDetails = (req, res) => {
  const parkId = req.params.id;

  _getParkDetailsAndPerformAction(parkId, (park, res) => {
    res.status(process.env.OK).json(park.parkDetails);
  }, res);
};

const removeParkDetails = (req, res) => {
  const parkId = req.params.id;

  _getParkDetailsAndPerformAction(parkId, (park, res) => {
    parkDetailsService.removeParkDetails(park, (error, park) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to remove park details" + error });
      } else {
        res.status(process.env.OK).json({ message: "ParkDetails deleted successfully" });
      }
    });
  }, res);
};

module.exports = {
  addParkDetails: addParkDetails,
  partialUpdateParkDetails: partialUpdateParkDetails,
  fullUpdateParkDetails: fullUpdateParkDetails,
  findParkDetails: findParkDetails,
  removeParkDetails: removeParkDetails
};
