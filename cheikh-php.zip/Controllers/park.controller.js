const parkService= require("../Services/park.service");

const addPark= (req, res) => {
  
  parkService.createPark(req.body ,(error, park) => {
        if(error){
            res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to create park" +error});
        }
       res.status(process.env.OK).json(park);
    });

  }

const getParks= (req, res) => {
    parkService.getAllParks((error, parks) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to retrieve parks" + error });
      } else {
        res.status(process.env.OK).json(parks);
      }
    });
  }
  
  const getParkById= (req, res) => {
    const parkId= req.params.id;
    parkService.getParkById(parkId, (error, park) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to retrieve park" + error });
      } else if (!park) {
        res.status(process.env.NOT_FOUND).json({ error: "Park not found" });
      } else {
        res.status(process.env.OK).json(park);
      }
    });
  }
  
  const partialUpdatePark= (req, res) => {
    parkService.partialUpdatePark(req.params.id, req.body, (error, park) => {
      updateParkCallback(error, park, res);
    });
  }
  const fullUpdatePark= (req, res) => {
    parkService.fullUpdatePark(req.params.id, req.body, (error, park) => {
      updateParkCallback(error, park, res);
    });
  }
  
  function updateParkCallback(error, park,res){
    if (error) {
      res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to update park" + error });
    } else if (!park) {
      res.status(process.env.NOT_FOUND).json({ error: "Park not found" });
    } else {
      res.status(process.env.OK).json(park);
    }
  }
  const deletePark= (req, res) => {
    const parkId= req.params.id;
    parkService.deletePark(parkId, (error, park) => {
      if (error) {
        res.status(process.env.SERVER_INTERNAL_ERROR).json({ error: "Failed to delete park" + error });
      } else if (!park) {
        res.status(process.env.NOT_FOUND).json({ error: "Park not found" });
      } else {
        res.status(process.env.OK).json({ message: "Park deleted successfully" });
      }
    });
  }

module.exports = {
    addPark: addPark,
    getParks: getParks,
    getParkById: getParkById,
    partialUpdatePark: partialUpdatePark,
    fullUpdatePark: fullUpdatePark,
    deletePark: deletePark
};
